package co.edu.unbosque.beans;

import co.edu.unbosque.model.User;
import co.edu.unbosque.service.UserService;
import co.edu.unbosque.util.exception.UserException;
import jakarta.inject.Inject;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named("registroBean")
@RequestScoped
public class RegistroBean implements Serializable {
    private String correo;
    private String password;
    private String rol = "USER";

    @Inject
    private UserService usuarioService;

    public String registrar() {
        try {
            User usuario = new User();
            usuario.setCorreo(correo);
            usuario.setPassword(password);
            usuario.setRol(rol);
            usuarioService.registrarUsuario(usuario);
            return "login?faces-redirect=true";
        } catch (UserException e) {
            System.out.println();
            return null;
        }
    }

    public RegistroBean() {
		// TODO Auto-generated constructor stub
	}

	public RegistroBean(String correo, String password, String rol, UserService usuarioService) {
		super();
		this.correo = correo;
		this.password = password;
		this.rol = rol;
		this.usuarioService = usuarioService;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public UserService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UserService usuarioService) {
		this.usuarioService = usuarioService;
	}
    
    
    
    
}