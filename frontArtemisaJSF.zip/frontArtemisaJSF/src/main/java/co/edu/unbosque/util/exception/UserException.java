package co.edu.unbosque.util.exception;

public class UserException extends Exception {
	public UserException(String mensaje) {
		super(mensaje);
	}
}
