package co.edu.unbosque.beans;

import co.edu.unbosque.service.UserService;
import jakarta.inject.Inject;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named("loginBean")
@SessionScoped
public class LoginBean implements Serializable {
	private String correo;
	private String password;
	private boolean logueado = false;

	@Inject
	private UserService usuarioService;

	public LoginBean() {
		// TODO Auto-generated constructor stub
	}

	public LoginBean(String correo, String password, boolean logueado, UserService usuarioService) {
		super();
		this.correo = correo;
		this.password = password;
		this.logueado = logueado;
		this.usuarioService = usuarioService;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isLogueado() {
		return logueado;
	}

	public void setLogueado(boolean logueado) {
		this.logueado = logueado;
	}

	public UserService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UserService usuarioService) {
		this.usuarioService = usuarioService;
	}

	public String login() {
		if (usuarioService.validarLogin(correo, password)) {
			logueado = true;
			return "index?faces-redirect=true";
		}
		return null;
	}

	public String logout() {
		logueado = false;
		correo = null;
		password = null;
		return "login?faces-redirect=true";
	}

}