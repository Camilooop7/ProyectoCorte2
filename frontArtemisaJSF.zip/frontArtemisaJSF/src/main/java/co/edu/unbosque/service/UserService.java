package co.edu.unbosque.service;

import co.edu.unbosque.model.User;
import co.edu.unbosque.util.exception.UserException;
//import co.edu.unbosque.util.exception.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@ApplicationScoped
@Named
public class UserService {

	@PersistenceContext(unitName = "defaultPU")
	private EntityManager em;

	@Transactional
	public void registrarUsuario(User usuario) throws UserException {
		if (usuario == null || usuario.getCorreo() == null || usuario.getPassword() == null) {
			throw new UserException("Datos inválidos");
		}
		em.persist(usuario);
	}

	public User buscarPorCorreo(String correo) {
		try {
			return em.createQuery("SELECT u FROM Usuario u WHERE u.correo = :correo", User.class)
					.setParameter("correo", correo).getSingleResult();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean validarLogin(String correo, String password) {
		User u = buscarPorCorreo(correo);
		return (u != null && u.getPassword().equals(password));
	}

}
